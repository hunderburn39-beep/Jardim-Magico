package pt.jardimmagico.jogo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebViewDatabase;
import android.widget.Toast;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String BASE = "https://appassets.androidplatform.net/";
    private static final int SAVE_HTML_REQUEST = 742;
    private WebView game;
    private String htmlToSave;
    private WebView printWebView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(20,15,39));
        getWindow().setNavigationBarColor(Color.rgb(20,15,39));
        game = new WebView(this);
        game.setBackgroundColor(Color.rgb(20,15,39));
        game.setVerticalScrollBarEnabled(false);
        game.setHorizontalScrollBarEnabled(false);
        game.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        WebSettings settings = game.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true); // preserva depósitos, saldos e configurações locais
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setDefaultTextEncodingName("utf-8");
        game.setWebChromeClient(new WebChromeClient());
        game.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (!"appassets.androidplatform.net".equals(u.getHost())) return null;
                String path = u.getPath();
                if (path == null || path.equals("/")) path = "/index.html";
                if (!path.equals("/index.html")) return new WebResourceResponse("text/plain", "UTF-8", null);
                try {
                    InputStream stream = getAssets().open("index.html");
                    return new WebResourceResponse("text/html", "UTF-8", stream);
                } catch (IOException e) {
                    return new WebResourceResponse("text/plain", "UTF-8", null);
                }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u=request.getUrl();
                if ("appassets.androidplatform.net".equals(u.getHost())) return false;
                if (request.isForMainFrame()) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, u)); }
                    catch (Exception e) { Toast.makeText(MainActivity.this,"Não foi possível abrir a ligação.",Toast.LENGTH_SHORT).show(); }
                    return true;
                }
                return false;
            }
        });
        game.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        setContentView(game);
        game.loadUrl(BASE + "index.html");
    }

    public class AndroidBridge {
        @JavascriptInterface public void saveHtml(String html) {
            if (html == null || html.isEmpty() || html.length()>2_000_000) return;
            runOnUiThread(() -> {
                htmlToSave = html;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("text/html");
                intent.putExtra(Intent.EXTRA_TITLE, "Jardim_Magico_Relatorio.html");
                startActivityForResult(intent, SAVE_HTML_REQUEST);
            });
        }
        @JavascriptInterface public void printHtml(String html) {
            if (html == null || html.isEmpty() || html.length()>2_000_000) return;
            runOnUiThread(() -> {
                if (printWebView != null) { printWebView.destroy(); printWebView = null; }
                printWebView = new WebView(MainActivity.this);
                printWebView.getSettings().setJavaScriptEnabled(false);
                printWebView.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        PrintManager manager=(PrintManager)getSystemService(PRINT_SERVICE);
                        manager.print("Jardim Mágico - Relatório", view.createPrintDocumentAdapter("Jardim Mágico"), null);
                    }
                });
                printWebView.loadDataWithBaseURL(BASE, html, "text/html", "UTF-8", null);
            });
        }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=SAVE_HTML_REQUEST) return;
        if(resultCode==RESULT_OK && data!=null && data.getData()!=null && htmlToSave!=null) {
            try(OutputStream out=getContentResolver().openOutputStream(data.getData())) {
                if(out!=null) {
                    out.write(htmlToSave.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this,"Relatório HTML guardado.",Toast.LENGTH_SHORT).show();
                }
            } catch(Exception e) {
                Toast.makeText(this,"Erro ao guardar relatório.",Toast.LENGTH_LONG).show();
            }
        }
        htmlToSave=null;
    }

    @Override public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        // WebView mantém a sessão e redimensiona-se automaticamente.
    }

    @Override public void onBackPressed() {
        new AlertDialog.Builder(this)
            .setTitle("Jardim Mágico")
            .setMessage("Queres sair do jogo? Os dados da sessão ficam guardados neste dispositivo.")
            .setNegativeButton("Continuar",(d,w)->{})
            .setPositiveButton("Sair",(d,w)->finish())
            .show();
    }

    @Override protected void onDestroy() {
        if (game!=null) {
            game.destroy();game=null;
        }
        if (printWebView!=null) {
            printWebView.destroy();printWebView=null;
        }
        super.onDestroy();
    }
}
